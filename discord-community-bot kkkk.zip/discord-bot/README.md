# 🔴 Discord Community Bot

Bot kamel dyal Discord feh **Music** + **Moderation** + **Community** (leveling, welcome, autorole, polls, giveaways...), jahz bash t-hostih b **Railway**.

## ⚠️ Muhim bezaf
Had bot kaykhdem b **bot token rasmi** (Discord Application), machi b "user token" f VC. L users tokens f automation mamnou3in b Discord ToS w kayadiw l ban dyal compte dyalek. Had l bot 100% qanouni w kaykhdem b l API rasmi dyal Discord.

## 📋 Features
- **🎵 Music**: `/play` `/skip` `/stop` `/pause` `/resume` `/queue` `/nowplaying` `/volume` `/loop` — YouTube + SoundCloud
- **🛡️ Moderation**: `/kick` `/ban` `/unban` `/timeout` `/warn` `/warnings` `/clear`
- **🎉 Community**: `/rank` `/leaderboard` `/poll` `/giveaway` `/avatar` `/userinfo` `/serverinfo` `/ping` `/help`
- **⚙️ Admin**: `/setwelcome` `/setautorole` `/announce`
- Leveling system automatique (XP mn messages)
- Welcome messages + Autorole l members jdod

## 🛠️ Étape 1 — Dir Application f Discord Developer Portal
1. Sir l https://discord.com/developers/applications
2. Cliqui "New Application" w 3tiha smiya
3. Mchi l tab **Bot** > "Add Bot"
4. Fdakhel "Privileged Gateway Intents" **fe77el** had trois:
   - `PRESENCE INTENT`
   - `SERVER MEMBERS INTENT`
   - `MESSAGE CONTENT INTENT`
5. Copier **Token** dyal bot (ghadi tkhdmha men b3d) — **matshareki-h m3a 7ed abadan**
6. Mchi l tab **OAuth2 > General**, copier **Client ID**
7. Mchi l **OAuth2 > URL Generator**:
   - Scopes: `bot`, `applications.commands`
   - Bot Permissions: `Administrator` (wla khtar li bghiti b yedd: Manage Roles, Kick, Ban, Moderate Members, Manage Messages, Connect, Speak, Send Messages...)
8. Copier link li tsawb, dir-h f browser w khtar server fin bghiti tzid bot

## 💻 Étape 2 — Jrreb local (ikhtiyari)
```bash
npm install
cp .env.example .env
# 3mmer .env b DISCORD_TOKEN w CLIENT_ID dyalek
npm run deploy   # bash tsajel slash commands
npm start        # bash tbda bot
```

## 📦 Étape 3 — Zid f GitHub
```bash
git init
git add .
git commit -m "Initial commit - Discord Community Bot"
git branch -M main
git remote add origin https://github.com/USERNAME/REPO-NAME.git
git push -u origin main
```
(`.env` mabghatch tzid m3ah f git — momnou3a f `.gitignore` bach matsribch token dyalek)

## 🚀 Étape 4 — Host b Railway
1. Sir l https://railway.app w dir login b GitHub
2. "New Project" > "Deploy from GitHub repo" > khtar repo dyalek
3. Railway ghadi yshouf `package.json` w yb9a ykhdem automatiquement (Nixpacks)
4. Mchi l tab **Variables** w zid:
   - `DISCORD_TOKEN` = token dyal bot
   - `CLIENT_ID` = Client ID dyal application
   - `GUILD_ID` = (ikhtiyari, l testing dghya f server wahed)
5. Bad ma tzid variables, Railway ghadi y-redeploy wa7dou
6. Bash tsajel slash commands 3la Railway, khtar chi wa7ed mn had 2:
   - **Sahla**: khddem `npm run deploy` mn PC dyalek 9bel matdir push (ghi khass ykon `.env` fih DISCORD_TOKEN + CLIENT_ID)
   - **Automatique**: zid f `package.json` script `"prestart": "node deploy-commands.js"` bash ysajel kol ma khdem

## 📁 Structure dyal Project
```
discord-bot/
├── index.js              # Main file
├── deploy-commands.js    # Script bash tsajel slash commands
├── commands/
│   ├── music/            # play, skip, stop, pause, resume, queue, nowplaying, volume, loop
│   ├── moderation/       # kick, ban, unban, timeout, warn, warnings, clear
│   ├── community/        # rank, leaderboard, poll, giveaway, avatar, userinfo, serverinfo, ping, help
│   └── admin/            # setwelcome, setautorole, announce
├── events/                # ready, interactionCreate, guildMemberAdd, messageCreate
├── utils/                 # database, levels, warnings, config, embeds
├── data/                  # JSON files (kaytsajlo automatiquement, mor deploy)
├── package.json
├── railway.json
├── Procfile
└── .env.example
```

## 🔧 Troubleshooting
- **Slash commands ma bayninch**: stnna chwiya (global ghadi ya5od ~1h), wla khdem b `GUILD_ID` bash yban dghya
- **Music ma khddamch**: t2akd `YtDlpPlugin` t7ml mzyan f Railway (kayb9a mn install), w bot 3andou permission `Connect` + `Speak`
- **Bot offline f Railway**: chouf logs f tab **Deployments**, t2akd DISCORD_TOKEN sa7i7

---
Sa3d bikhir! 🔴
