const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

function filePath(name) {
  return path.join(DATA_DIR, `${name}.json`);
}

function load(name) {
  const fp = filePath(name);
  if (!fs.existsSync(fp)) {
    fs.writeFileSync(fp, JSON.stringify({}, null, 2));
    return {};
  }
  try {
    return JSON.parse(fs.readFileSync(fp, 'utf8'));
  } catch (e) {
    return {};
  }
}

function save(name, data) {
  fs.writeFileSync(filePath(name), JSON.stringify(data, null, 2));
}

// --- Generic get/set helpers, scoped per guild ---
function getGuildData(name, guildId) {
  const all = load(name);
  if (!all[guildId]) all[guildId] = {};
  return all[guildId];
}

function setGuildData(name, guildId, value) {
  const all = load(name);
  all[guildId] = value;
  save(name, all);
}

module.exports = { load, save, getGuildData, setGuildData };
