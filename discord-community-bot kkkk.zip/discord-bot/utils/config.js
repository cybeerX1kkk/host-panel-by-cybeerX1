const { getGuildData, setGuildData } = require('./database');
const FILE = 'config';

function getConfig(guildId) {
  return getGuildData(FILE, guildId);
}

function setConfig(guildId, key, value) {
  const cfg = getGuildData(FILE, guildId);
  cfg[key] = value;
  setGuildData(FILE, guildId, cfg);
  return cfg;
}

module.exports = { getConfig, setConfig };
