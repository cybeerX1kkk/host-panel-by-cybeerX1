const { load, save } = require('./database');

const FILE = 'levels';

function xpForLevel(level) {
  return 5 * (level ** 2) + 50 * level + 100;
}

function getUser(guildId, userId) {
  const all = load(FILE);
  if (!all[guildId]) all[guildId] = {};
  if (!all[guildId][userId]) all[guildId][userId] = { xp: 0, level: 0, lastMessage: 0 };
  return all[guildId][userId];
}

function saveAll(all) {
  save(FILE, all);
}

function addXp(guildId, userId, amount) {
  const all = load(FILE);
  if (!all[guildId]) all[guildId] = {};
  if (!all[guildId][userId]) all[guildId][userId] = { xp: 0, level: 0, lastMessage: 0 };

  const user = all[guildId][userId];
  const now = Date.now();
  // Cooldown dyal 60 seconds bach matzadch XP b sur3a bezaf
  if (now - user.lastMessage < 60000) {
    return { leveledUp: false, level: user.level };
  }
  user.lastMessage = now;
  user.xp += amount;

  let leveledUp = false;
  while (user.xp >= xpForLevel(user.level)) {
    user.xp -= xpForLevel(user.level);
    user.level += 1;
    leveledUp = true;
  }

  saveAll(all);
  return { leveledUp, level: user.level };
}

function getLeaderboard(guildId, limit = 10) {
  const all = load(FILE);
  const guildData = all[guildId] || {};
  return Object.entries(guildData)
    .map(([userId, data]) => ({ userId, ...data }))
    .sort((a, b) => (b.level - a.level) || (b.xp - a.xp))
    .slice(0, limit);
}

module.exports = { getUser, addXp, getLeaderboard, xpForLevel };
