const { load, save } = require('./database');
const FILE = 'warnings';

function addWarning(guildId, userId, reason, moderatorId) {
  const all = load(FILE);
  if (!all[guildId]) all[guildId] = {};
  if (!all[guildId][userId]) all[guildId][userId] = [];
  const warning = { reason, moderatorId, date: new Date().toISOString() };
  all[guildId][userId].push(warning);
  save(FILE, all);
  return all[guildId][userId].length;
}

function getWarnings(guildId, userId) {
  const all = load(FILE);
  return (all[guildId] && all[guildId][userId]) || [];
}

function clearWarnings(guildId, userId) {
  const all = load(FILE);
  if (all[guildId]) all[guildId][userId] = [];
  save(FILE, all);
}

module.exports = { addWarning, getWarnings, clearWarnings };
