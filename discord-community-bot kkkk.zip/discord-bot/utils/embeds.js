const { EmbedBuilder } = require('discord.js');

const COLOR = 0xE63946; // 7mer (red theme)
const COLOR_SUCCESS = 0x2ECC71;
const COLOR_ERROR = 0xE63946;

function baseEmbed() {
  return new EmbedBuilder().setColor(COLOR).setTimestamp();
}

function successEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(COLOR_SUCCESS)
    .setTitle(`✅ ${title}`)
    .setDescription(description || null)
    .setTimestamp();
}

function errorEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(COLOR_ERROR)
    .setTitle(`❌ ${title}`)
    .setDescription(description || null)
    .setTimestamp();
}

function infoEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(COLOR)
    .setTitle(title)
    .setDescription(description || null)
    .setTimestamp();
}

module.exports = { baseEmbed, successEmbed, errorEmbed, infoEmbed, COLOR };
