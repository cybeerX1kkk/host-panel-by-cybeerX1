require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');

const commands = [];
const foldersPath = path.join(__dirname, 'commands');
const commandFolders = fs.readdirSync(foldersPath);

for (const folder of commandFolders) {
  const folderPath = path.join(foldersPath, folder);
  const commandFiles = fs.readdirSync(folderPath).filter(f => f.endsWith('.js'));
  for (const file of commandFiles) {
    const command = require(path.join(folderPath, file));
    if (command.data) commands.push(command.data.toJSON());
  }
}

const rest = new REST().setToken(process.env.DISCORD_TOKEN);

(async () => {
  try {
    console.log(`🔄 Kansajel ${commands.length} slash commands...`);

    const route = process.env.GUILD_ID
      ? Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID)
      : Routes.applicationCommands(process.env.CLIENT_ID);

    const data = await rest.put(route, { body: commands });

    console.log(`✅ Tsajlo ${data.length} commands b najah!`);
    if (process.env.GUILD_ID) {
      console.log('ℹ️  Tsajlo f server wa7ed (GUILD_ID mojoud) - ghadi yban dghya.');
    } else {
      console.log('ℹ️  Tsajlo global - ghadi ya5od chi sa3a bash yban f ga3 les servers.');
    }
  } catch (err) {
    console.error('❌ Wq3 error:', err);
  }
})();
