require('dotenv').config();
const fs = require('fs');
const path = require('path');
const express = require('express');
const { Client, GatewayIntentBits, Collection, Partials } = require('discord.js');
const { DisTube } = require('distube');
const { YtDlpPlugin } = require('@distube/yt-dlp');
const { SoundCloudPlugin } = require('@distube/soundcloud');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMessageReactions,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction],
});

// --- Load commands ---
client.commands = new Collection();
const commandsPath = path.join(__dirname, 'commands');
const commandFolders = fs.readdirSync(commandsPath);

for (const folder of commandFolders) {
  const folderPath = path.join(commandsPath, folder);
  const commandFiles = fs.readdirSync(folderPath).filter(f => f.endsWith('.js'));
  for (const file of commandFiles) {
    const command = require(path.join(folderPath, file));
    if (command.data && command.execute) {
      client.commands.set(command.data.name, command);
    }
  }
}

// --- Load events ---
const eventsPath = path.join(__dirname, 'events');
const eventFiles = fs.readdirSync(eventsPath).filter(f => f.endsWith('.js'));

for (const file of eventFiles) {
  const event = require(path.join(eventsPath, file));
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args, client));
  } else {
    client.on(event.name, (...args) => event.execute(...args, client));
  }
}

// --- DisTube (music) setup ---
client.distube = new DisTube(client, {
  emitNewSongOnly: true,
  plugins: [
    new YtDlpPlugin({ update: false }),
    new SoundCloudPlugin(),
  ],
});

client.distube
  .on('playSong', (queue, song) => {
    queue.textChannel?.send(`🎶 Daba kat-l3eb: **${song.name}** - \`${song.formattedDuration}\` | Tzada mn ${song.user}`);
  })
  .on('addSong', (queue, song) => {
    queue.textChannel?.send(`➕ Tzadat l queue: **${song.name}** - \`${song.formattedDuration}\``);
  })
  .on('error', (channel, error) => {
    console.error('DisTube error:', error);
    channel?.send('❌ Wq3 chi mochkil f music, jrb men b3d.').catch(() => {});
  })
  .on('finish', queue => {
    queue.textChannel?.send('✅ Sala l queue dyal music.').catch(() => {});
  })
  .on('empty', queue => {
    queue.textChannel?.send('👋 Khrejt mn voice channel 7it makan 7ed.').catch(() => {});
  });

// --- Tiny web server (health-check dyal Railway) ---
const app = express();
app.get('/', (req, res) => {
  res.send(`
    <html>
      <head><title>Bot Status</title></head>
      <body style="background:#1a1a1a;color:#E63946;font-family:sans-serif;text-align:center;padding-top:80px;">
        <h1>🔴 Bot Online</h1>
        <p style="color:#eee;">${client.user ? client.user.tag : 'Kaybda...'}</p>
        <p style="color:#888;">Servers: ${client.guilds ? client.guilds.cache.size : 0}</p>
      </body>
    </html>
  `);
});
app.listen(process.env.PORT || 3000, () => console.log(`🌐 Web server khddam 3la port ${process.env.PORT || 3000}`));

client.login(process.env.DISCORD_TOKEN);
