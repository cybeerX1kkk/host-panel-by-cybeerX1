const { addXp } = require('../utils/levels');
const { successEmbed } = require('../utils/embeds');

module.exports = {
  name: 'messageCreate',
  async execute(message) {
    if (message.author.bot || !message.guild) return;

    const xpGain = Math.floor(Math.random() * 10) + 5; // 5-15 XP
    const result = addXp(message.guildId, message.author.id, xpGain);

    if (result.leveledUp) {
      message.channel.send({
        embeds: [successEmbed('🎉 Level Up!', `Mabrouk ${message.author}! Dozti l **Level ${result.level}**`)],
      }).catch(() => {});
    }
  },
};
