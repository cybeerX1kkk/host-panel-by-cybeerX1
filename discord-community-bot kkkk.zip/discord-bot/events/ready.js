const { ActivityType } = require('discord.js');

module.exports = {
  name: 'ready',
  once: true,
  execute(client) {
    console.log(`✅ Bot dial l3eb b smiyat: ${client.user.tag}`);
    console.log(`📊 Kayn f ${client.guilds.cache.size} server(at)`);

    client.user.setPresence({
      activities: [{ name: '/help | 🎵 Music', type: ActivityType.Listening }],
      status: 'online',
    });
  },
};
