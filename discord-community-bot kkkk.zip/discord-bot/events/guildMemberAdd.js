const { getConfig } = require('../utils/config');
const { infoEmbed } = require('../utils/embeds');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member) {
    const cfg = getConfig(member.guild.id);

    // Welcome message
    if (cfg.welcomeChannelId && cfg.welcomeMessage) {
      const channel = member.guild.channels.cache.get(cfg.welcomeChannelId);
      if (channel) {
        const text = cfg.welcomeMessage
          .replaceAll('{user}', `<@${member.id}>`)
          .replaceAll('{server}', member.guild.name);
        channel.send({ embeds: [infoEmbed('👋 Marhba!', text).setThumbnail(member.user.displayAvatarURL())] }).catch(() => {});
      }
    }

    // Autorole
    if (cfg.autoRoleId) {
      const role = member.guild.roles.cache.get(cfg.autoRoleId);
      if (role) {
        member.roles.add(role).catch(() => {});
      }
    }
  },
};
