const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { errorEmbed, successEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Sket chi membre (mute) chi mudda')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(opt => opt.setName('membre').setDescription('Chkoun').setRequired(true))
    .addIntegerOption(opt => opt.setName('da9ay9').setDescription('Chhal mn di9a').setRequired(true).setMinValue(1).setMaxValue(40320))
    .addStringOption(opt => opt.setName('sabab').setDescription('3lach')),
  async execute(interaction) {
    const target = interaction.options.getUser('membre');
    const minutes = interaction.options.getInteger('da9ay9');
    const reason = interaction.options.getString('sabab') || 'Ma kayn walo';

    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (!member) return interaction.reply({ embeds: [errorEmbed('Ma lqitouch', 'Had membre machi f server.')], ephemeral: true });
    if (!member.moderatable) return interaction.reply({ embeds: [errorEmbed('Ma9drtch', 'Ma9drtch nsketou (rank 3ali).')], ephemeral: true });

    await member.timeout(minutes * 60 * 1000, reason);
    await interaction.reply({ embeds: [successEmbed('Tsket', `**${target.tag}** tsket mudda **${minutes}** di9a.\nSabab: ${reason}`)] });
  },
};
