const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed } = require('../../utils/embeds');
const { addWarning } = require('../../utils/warnings');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('3ti warning l chi membre')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(opt => opt.setName('membre').setDescription('Chkoun').setRequired(true))
    .addStringOption(opt => opt.setName('sabab').setDescription('3lach').setRequired(true)),
  async execute(interaction) {
    const target = interaction.options.getUser('membre');
    const reason = interaction.options.getString('sabab');

    const count = addWarning(interaction.guildId, target.id, reason, interaction.user.id);
    await interaction.reply({ embeds: [successEmbed('Warning Tzadat', `**${target.tag}** 3andou daba **${count}** warning(s).\nSabab: ${reason}`)] });

    target.send(`⚠️ 3titik warning f server **${interaction.guild.name}**\nSabab: ${reason}`).catch(() => {});
  },
};
