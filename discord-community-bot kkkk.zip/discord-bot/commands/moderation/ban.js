const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { errorEmbed, successEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Bannih mn server')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption(opt => opt.setName('membre').setDescription('Chkoun bghiti tbannih').setRequired(true))
    .addStringOption(opt => opt.setName('sabab').setDescription('3lach')),
  async execute(interaction) {
    const target = interaction.options.getUser('membre');
    const reason = interaction.options.getString('sabab') || 'Ma kayn walo';

    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (member && !member.bannable) {
      return interaction.reply({ embeds: [errorEmbed('Ma9drtch', 'Ma9drtch nbannih (rank 3ali).')], ephemeral: true });
    }

    await interaction.guild.members.ban(target.id, { reason });
    await interaction.reply({ embeds: [successEmbed('Tbanna', `**${target.tag}** tbanna mn server.\nSabab: ${reason}`)] });
  },
};
