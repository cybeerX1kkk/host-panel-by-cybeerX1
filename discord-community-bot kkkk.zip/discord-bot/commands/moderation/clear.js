const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { errorEmbed, successEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Msa7 chi 3adad d messages mn channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addIntegerOption(opt => opt.setName('3adad').setDescription('Chhal mn message (1-100)').setRequired(true).setMinValue(1).setMaxValue(100)),
  async execute(interaction) {
    const amount = interaction.options.getInteger('3adad');
    try {
      const deleted = await interaction.channel.bulkDelete(amount, true);
      await interaction.reply({ embeds: [successEmbed('Tmsa7o', `Tmsa7o **${deleted.size}** messages.`)], ephemeral: true });
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed('Ma9drtch', 'Ma9drtch nmsa7, wa9ila les messages 9dimin (+14 youm).')], ephemeral: true });
    }
  },
};
