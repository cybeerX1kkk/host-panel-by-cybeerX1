const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { errorEmbed, successEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Fk l ban 3la chi user')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addStringOption(opt => opt.setName('id').setDescription('User ID dyal li bghiti tfek 3lih').setRequired(true)),
  async execute(interaction) {
    const id = interaction.options.getString('id');
    try {
      await interaction.guild.members.unban(id);
      await interaction.reply({ embeds: [successEmbed('Tfek l Ban', `User b ID \`${id}\` tfek 3lih l ban.`)] });
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed('Ma9drtch', 'Had ID machi mbanni wla ghalat.')], ephemeral: true });
    }
  },
};
