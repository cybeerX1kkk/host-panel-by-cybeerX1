const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { infoEmbed } = require('../../utils/embeds');
const { getWarnings, clearWarnings } = require('../../utils/warnings');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('Wri wla msa7 les warnings dyal chi membre')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(opt => opt.setName('membre').setDescription('Chkoun').setRequired(true))
    .addBooleanOption(opt => opt.setName('msa7').setDescription('Msa7 ga3 les warnings dyalou?')),
  async execute(interaction) {
    const target = interaction.options.getUser('membre');
    const clear = interaction.options.getBoolean('msa7');

    if (clear) {
      clearWarnings(interaction.guildId, target.id);
      return interaction.reply({ embeds: [infoEmbed('🧹 Tmsa7o', `Ga3 les warnings dyal **${target.tag}** tmsa7o.`)] });
    }

    const warnings = getWarnings(interaction.guildId, target.id);
    if (warnings.length === 0) {
      return interaction.reply({ embeds: [infoEmbed('Makayn Warnings', `**${target.tag}** ma3andou hta warning.`)] });
    }

    const list = warnings.map((w, i) => `**${i + 1}.** ${w.reason} - <t:${Math.floor(new Date(w.date).getTime() / 1000)}:R>`).join('\n');
    await interaction.reply({ embeds: [infoEmbed(`⚠️ Warnings dyal ${target.tag}`, list)] });
  },
};
