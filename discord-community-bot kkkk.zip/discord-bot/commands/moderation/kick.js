const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { errorEmbed, successEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('9lb 3la chi membre mn server')
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption(opt => opt.setName('membre').setDescription('Chkoun bghiti تقلب عليه').setRequired(true))
    .addStringOption(opt => opt.setName('sabab').setDescription('3lach')),
  async execute(interaction) {
    const target = interaction.options.getUser('membre');
    const reason = interaction.options.getString('sabab') || 'Ma kayn walo';
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) return interaction.reply({ embeds: [errorEmbed('Ma lqitouch', 'Had membre machi f server.')], ephemeral: true });
    if (!member.kickable) return interaction.reply({ embeds: [errorEmbed('Ma9drtch', 'Ma9drtch n9leb 3la had membre (rank 3ali).')], ephemeral: true });

    await member.kick(reason);
    await interaction.reply({ embeds: [successEmbed('Tqleb 3lih', `**${target.tag}** tqleb 3lih.\nSabab: ${reason}`)] });
  },
};
