const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { infoEmbed, successEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('announce')
    .setDescription('Sift I3lan f chi channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addChannelOption(opt => opt.setName('channel').setDescription('Fin').addChannelTypes(ChannelType.GuildText).setRequired(true))
    .addStringOption(opt => opt.setName('message').setDescription('Message dyal I3lan').setRequired(true)),
  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    const message = interaction.options.getString('message');

    await channel.send({ embeds: [infoEmbed('📢 I3lan', message)] });
    await interaction.reply({ embeds: [successEmbed('Tsift', `I3lan tsift f ${channel}`)], ephemeral: true });
  },
};
