const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { setConfig } = require('../../utils/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setautorole')
    .setDescription('Sabet role li kayt3ti automatiquement l member jdid')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addRoleOption(opt => opt.setName('role').setDescription('Ach role').setRequired(true)),
  async execute(interaction) {
    const role = interaction.options.getRole('role');

    if (role.managed || role.id === interaction.guild.id) {
      return interaction.reply({ embeds: [errorEmbed('Ma9dartch', 'Ma9dartch nkhtar had role.')], ephemeral: true });
    }

    setConfig(interaction.guildId, 'autoRoleId', role.id);
    await interaction.reply({ embeds: [successEmbed('Autorole Msabet', `Members jdod ghadi ya5do role: ${role}`)] });
  },
};
