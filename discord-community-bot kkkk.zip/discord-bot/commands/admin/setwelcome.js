const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { successEmbed } = require('../../utils/embeds');
const { setConfig } = require('../../utils/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setwelcome')
    .setDescription('Sabet channel w message dyal welcome l members jdod')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addChannelOption(opt => opt.setName('channel').setDescription('Fin ghadi ykon message').addChannelTypes(ChannelType.GuildText).setRequired(true))
    .addStringOption(opt => opt.setName('message').setDescription('Ktb {user} bash tdkhol smiya, {server} l smiyat server').setRequired(true)),
  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    const message = interaction.options.getString('message');

    setConfig(interaction.guildId, 'welcomeChannelId', channel.id);
    setConfig(interaction.guildId, 'welcomeMessage', message);

    await interaction.reply({ embeds: [successEmbed('Welcome Msabet', `Channel: ${channel}\nMessage: ${message}`)] });
  },
};
