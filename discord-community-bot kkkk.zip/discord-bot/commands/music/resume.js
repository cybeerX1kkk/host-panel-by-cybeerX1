const { SlashCommandBuilder } = require('discord.js');
const { errorEmbed, successEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('resume').setDescription('Kamel l music'),
  async execute(interaction) {
    const queue = interaction.client.distube.getQueue(interaction.guildId);
    if (!queue) return interaction.reply({ embeds: [errorEmbed('Makayn walo', 'Makayn music kat-l3eb daba.')], ephemeral: true });
    queue.resume();
    await interaction.reply({ embeds: [successEmbed('▶️ Kamlat', 'Music rj3at kat-l3eb.')] });
  },
};
