const { SlashCommandBuilder } = require('discord.js');
const { errorEmbed, infoEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('play')
    .setDescription('Lعب nghma mn YouTube/SoundCloud (b smiya wla link)')
    .addStringOption(opt =>
      opt.setName('query')
        .setDescription('Smiyat nghma wla link')
        .setRequired(true)),
  async execute(interaction) {
    const query = interaction.options.getString('query');
    const voiceChannel = interaction.member.voice.channel;

    if (!voiceChannel) {
      return interaction.reply({ embeds: [errorEmbed('Khasek tkoun f Voice Channel', 'Dkhol l chi voice channel mnin ghadi تلعب موسيقى.')], ephemeral: true });
    }

    const permissions = voiceChannel.permissionsFor(interaction.client.user);
    if (!permissions.has('Connect') || !permissions.has('Speak')) {
      return interaction.reply({ embeds: [errorEmbed('Ma3andich permissions', 'Khasni permission Connect w Speak f had voice channel.')], ephemeral: true });
    }

    await interaction.deferReply();

    try {
      await interaction.client.distube.play(voiceChannel, query, {
        member: interaction.member,
        textChannel: interaction.channel,
      });
      await interaction.editReply({ embeds: [infoEmbed('🔎 Kanqleb...', `Kanqleb 3la: **${query}**`)] });
    } catch (err) {
      console.error(err);
      await interaction.editReply({ embeds: [errorEmbed('Wq3 chi mochkil', 'Ma9drtch nl3b hadchi, jrb link wla smiya khra.')] });
    }
  },
};
