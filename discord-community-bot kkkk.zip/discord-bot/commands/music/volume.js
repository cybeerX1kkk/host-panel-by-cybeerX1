const { SlashCommandBuilder } = require('discord.js');
const { errorEmbed, successEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('volume')
    .setDescription('Bddel l volume dyal music (0-100)')
    .addIntegerOption(opt => opt.setName('niveau').setDescription('Volume mn 0 l 100').setRequired(true).setMinValue(0).setMaxValue(100)),
  async execute(interaction) {
    const queue = interaction.client.distube.getQueue(interaction.guildId);
    if (!queue) return interaction.reply({ embeds: [errorEmbed('Makayn walo', 'Makayn music kat-l3eb daba.')], ephemeral: true });

    const level = interaction.options.getInteger('niveau');
    queue.setVolume(level);
    await interaction.reply({ embeds: [successEmbed('🔊 Volume Tbeddel', `Volume daba: **${level}%**`)] });
  },
};
