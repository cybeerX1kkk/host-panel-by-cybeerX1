const { SlashCommandBuilder } = require('discord.js');
const { errorEmbed, infoEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('nowplaying').setDescription('Wri nghma li kat-l3eb daba'),
  async execute(interaction) {
    const queue = interaction.client.distube.getQueue(interaction.guildId);
    if (!queue) return interaction.reply({ embeds: [errorEmbed('Makayn walo', 'Makayn music kat-l3eb daba.')], ephemeral: true });

    const song = queue.songs[0];
    const embed = infoEmbed('🎧 Daba kat-l3eb', `**${song.name}**\n\`${song.formattedDuration}\` | Volume: ${queue.volume}%`)
      .setThumbnail(song.thumbnail || null)
      .setURL(song.url || null);

    await interaction.reply({ embeds: [embed] });
  },
};
