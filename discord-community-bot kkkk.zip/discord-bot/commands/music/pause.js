const { SlashCommandBuilder } = require('discord.js');
const { errorEmbed, successEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('pause').setDescription('W9ef music mo2aqatan'),
  async execute(interaction) {
    const queue = interaction.client.distube.getQueue(interaction.guildId);
    if (!queue) return interaction.reply({ embeds: [errorEmbed('Makayn walo', 'Makayn music kat-l3eb daba.')], ephemeral: true });
    queue.pause();
    await interaction.reply({ embeds: [successEmbed('⏸️ Pause', 'Music twa9fat mo2aqatan.')] });
  },
};
