const { SlashCommandBuilder } = require('discord.js');
const { errorEmbed, successEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('loop')
    .setDescription('Bddel mode dyal loop')
    .addStringOption(opt =>
      opt.setName('mode')
        .setDescription('Khtar mode')
        .setRequired(true)
        .addChoices(
          { name: 'Khawi (bla loop)', value: 'off' },
          { name: 'Nghma wahda', value: 'song' },
          { name: 'Queue kamla', value: 'queue' },
        )),
  async execute(interaction) {
    const queue = interaction.client.distube.getQueue(interaction.guildId);
    if (!queue) return interaction.reply({ embeds: [errorEmbed('Makayn walo', 'Makayn music kat-l3eb daba.')], ephemeral: true });

    const mode = interaction.options.getString('mode');
    const map = { off: 0, song: 1, queue: 2 };
    queue.setRepeatMode(map[mode]);

    const labels = { off: 'Khawi', song: 'Nghma wahda 🔂', queue: 'Queue kamla 🔁' };
    await interaction.reply({ embeds: [successEmbed('Loop Tbeddel', `Mode daba: **${labels[mode]}**`)] });
  },
};
