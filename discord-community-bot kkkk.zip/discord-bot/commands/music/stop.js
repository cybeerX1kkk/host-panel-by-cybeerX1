const { SlashCommandBuilder } = require('discord.js');
const { errorEmbed, successEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('stop').setDescription('Wa9ef music w 5rej mn voice channel'),
  async execute(interaction) {
    const queue = interaction.client.distube.getQueue(interaction.guildId);
    if (!queue) return interaction.reply({ embeds: [errorEmbed('Makayn walo', 'Makayn music kat-l3eb daba.')], ephemeral: true });

    queue.stop();
    await interaction.reply({ embeds: [successEmbed('Tw9fat Music', 'Khrejt mn voice channel.')] });
  },
};
