const { SlashCommandBuilder } = require('discord.js');
const { errorEmbed, successEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('skip').setDescription('9bez l nghma li mn b3d'),
  async execute(interaction) {
    const queue = interaction.client.distube.getQueue(interaction.guildId);
    if (!queue) return interaction.reply({ embeds: [errorEmbed('Makayn walo', 'Makayn queue dyal music daba.')], ephemeral: true });

    try {
      const song = queue.songs[1];
      await queue.skip();
      await interaction.reply({ embeds: [successEmbed('Tskip-at', song ? `Daba kat-l3eb: **${song.name}**` : 'Skipped')] });
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed('Ma9drtch nskip', 'Wqe3 walla hadi akher nghma f queue.')], ephemeral: true });
    }
  },
};
