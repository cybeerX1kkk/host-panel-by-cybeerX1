const { SlashCommandBuilder } = require('discord.js');
const { errorEmbed, infoEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('queue').setDescription('Wri l9a2ima dyal l aghani'),
  async execute(interaction) {
    const queue = interaction.client.distube.getQueue(interaction.guildId);
    if (!queue) return interaction.reply({ embeds: [errorEmbed('Makayn walo', 'Makayn queue daba.')], ephemeral: true });

    const list = queue.songs
      .slice(0, 15)
      .map((song, i) => `${i === 0 ? '▶️' : `${i}.`} **${song.name}** - \`${song.formattedDuration}\` ${song.user ? `(${song.user.username})` : ''}`)
      .join('\n');

    const embed = infoEmbed('🎶 Queue dyal Music', list)
      .setFooter({ text: `Total: ${queue.songs.length} nghma | Volume: ${queue.volume}%` });

    await interaction.reply({ embeds: [embed] });
  },
};
