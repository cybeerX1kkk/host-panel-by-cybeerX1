const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('help').setDescription('Wri ga3 l commands dyal bot'),
  async execute(interaction) {
    const embed = infoEmbed('📖 Commands dyal Bot', null)
      .addFields(
        { name: '🎵 Music', value: '`/play` `/skip` `/stop` `/pause` `/resume` `/queue` `/nowplaying` `/volume` `/loop`' },
        { name: '🛡️ Moderation', value: '`/kick` `/ban` `/unban` `/timeout` `/warn` `/warnings` `/clear`' },
        { name: '🎉 Community', value: '`/rank` `/leaderboard` `/poll` `/giveaway` `/avatar` `/userinfo` `/serverinfo` `/ping`' },
        { name: '⚙️ Admin', value: '`/setwelcome` `/setautorole` `/announce`' },
      )
      .setFooter({ text: 'Bot dyal Community 🔴' });

    await interaction.reply({ embeds: [embed] });
  },
};
