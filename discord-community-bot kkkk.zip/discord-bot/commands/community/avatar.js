const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('avatar')
    .setDescription('Wri sourat dyal chi membre')
    .addUserOption(opt => opt.setName('membre').setDescription('Chkoun')),
  async execute(interaction) {
    const target = interaction.options.getUser('membre') || interaction.user;
    const embed = infoEmbed(`🖼️ Avatar dyal ${target.username}`, null)
      .setImage(target.displayAvatarURL({ size: 512 }));
    await interaction.reply({ embeds: [embed] });
  },
};
