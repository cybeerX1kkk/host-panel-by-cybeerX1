const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embeds');
const { getLeaderboard } = require('../../utils/levels');

module.exports = {
  data: new SlashCommandBuilder().setName('leaderboard').setDescription('Top 10 dyal l members b XP 3alya'),
  async execute(interaction) {
    const top = getLeaderboard(interaction.guildId, 10);
    if (top.length === 0) {
      return interaction.reply({ embeds: [infoEmbed('Makayn Walo', 'Hta membre ma3andou XP baed.')] });
    }

    const medals = ['🥇', '🥈', '🥉'];
    const lines = await Promise.all(top.map(async (entry, i) => {
      const user = await interaction.client.users.fetch(entry.userId).catch(() => null);
      const name = user ? user.username : 'Unknown';
      const rank = medals[i] || `**${i + 1}.**`;
      return `${rank} ${name} — Level ${entry.level} (${entry.xp} XP)`;
    }));

    await interaction.reply({ embeds: [infoEmbed('🏆 Leaderboard', lines.join('\n'))] });
  },
};
