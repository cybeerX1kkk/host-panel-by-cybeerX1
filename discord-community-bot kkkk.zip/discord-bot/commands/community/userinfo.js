const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('Wri ma3loumat 3la chi membre')
    .addUserOption(opt => opt.setName('membre').setDescription('Chkoun')),
  async execute(interaction) {
    const target = interaction.options.getUser('membre') || interaction.user;
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    const embed = infoEmbed(`👤 ${target.username}`, null)
      .setThumbnail(target.displayAvatarURL())
      .addFields(
        { name: 'ID', value: target.id, inline: true },
        { name: 'Dkhel Discord', value: `<t:${Math.floor(target.createdTimestamp / 1000)}:D>`, inline: true },
        { name: 'Dkhel Server', value: member ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:D>` : 'Majhoul', inline: true },
        { name: 'Roles', value: member ? member.roles.cache.filter(r => r.id !== interaction.guild.id).map(r => r.toString()).join(' ') || 'Makayn' : 'Majhoul' },
      );

    await interaction.reply({ embeds: [embed] });
  },
};
