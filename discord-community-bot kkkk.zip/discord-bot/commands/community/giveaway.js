const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { infoEmbed, successEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('Bda giveaway f channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addStringOption(opt => opt.setName('jayza').setDescription('Ach ghadi yrb7 l fayz').setRequired(true))
    .addIntegerOption(opt => opt.setName('da9ay9').setDescription('Ghadi ydom chhal mn di9a').setRequired(true).setMinValue(1).setMaxValue(10080)),
  async execute(interaction) {
    const prize = interaction.options.getString('jayza');
    const minutes = interaction.options.getInteger('da9ay9');
    const endTime = Math.floor(Date.now() / 1000) + minutes * 60;

    const embed = infoEmbed('🎉 GIVEAWAY 🎉', `**Jayza:** ${prize}\n**Kaysd today l:** <t:${endTime}:R>\n\nDwez b 🎉 bash tdkhol!`)
      .setFooter({ text: `Organizer: ${interaction.user.username}` });

    const message = await interaction.reply({ embeds: [embed], fetchReply: true });
    await message.react('🎉');

    setTimeout(async () => {
      try {
        const fetched = await interaction.channel.messages.fetch(message.id);
        const reaction = fetched.reactions.cache.get('🎉');
        if (!reaction) return;

        const users = await reaction.users.fetch();
        const participants = users.filter(u => !u.bot);

        if (participants.size === 0) {
          return interaction.channel.send({ embeds: [infoEmbed('Giveaway Sala', `Hta chi 7ed ma dwez, makayn fayz l **${prize}**.`)] });
        }

        const winner = participants.random();
        await interaction.channel.send({ embeds: [successEmbed('🎉 Giveaway Sala!', `Mabrouk ${winner}! Rbe7ti **${prize}**`)] });
      } catch (err) {
        console.error('Giveaway error:', err);
      }
    }, minutes * 60 * 1000);
  },
};
