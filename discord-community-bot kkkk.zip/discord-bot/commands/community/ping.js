const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('ping').setDescription('Chouf sur3at l bot'),
  async execute(interaction) {
    const sent = await interaction.reply({ embeds: [infoEmbed('🏓 Pong!', 'Kanhseb...')], fetchReply: true });
    const latency = sent.createdTimestamp - interaction.createdTimestamp;
    await interaction.editReply({ embeds: [infoEmbed('🏓 Pong!', `Latency: **${latency}ms**\nAPI: **${Math.round(interaction.client.ws.ping)}ms**`)] });
  },
};
