const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embeds');

const NUMBER_EMOJIS = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣'];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('poll')
    .setDescription('Dir sondage b vote')
    .addStringOption(opt => opt.setName('souaal').setDescription('Souaal dyal sondage').setRequired(true))
    .addStringOption(opt => opt.setName('ikhtiyarat').setDescription('Ikhtiyarat mfsolin b " , " (khliha khawya bash ykoun 👍/👎)')),
  async execute(interaction) {
    const question = interaction.options.getString('souaal');
    const optionsRaw = interaction.options.getString('ikhtiyarat');

    if (!optionsRaw) {
      const embed = infoEmbed(`📊 ${question}`, `Dwzo b 👍 wla 👎`).setFooter({ text: `Sondage mn ${interaction.user.username}` });
      const reply = await interaction.reply({ embeds: [embed], fetchReply: true });
      await reply.react('👍');
      await reply.react('👎');
      return;
    }

    const options = optionsRaw.split(',').map(o => o.trim()).filter(Boolean).slice(0, 5);
    const desc = options.map((o, i) => `${NUMBER_EMOJIS[i]} ${o}`).join('\n');
    const embed = infoEmbed(`📊 ${question}`, desc).setFooter({ text: `Sondage mn ${interaction.user.username}` });
    const reply = await interaction.reply({ embeds: [embed], fetchReply: true });

    for (let i = 0; i < options.length; i++) {
      await reply.react(NUMBER_EMOJIS[i]);
    }
  },
};
