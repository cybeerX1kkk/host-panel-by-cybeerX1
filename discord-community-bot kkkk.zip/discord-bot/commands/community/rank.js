const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embeds');
const { getUser, xpForLevel } = require('../../utils/levels');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rank')
    .setDescription('Wri level w XP dyalek wla dyal chi membre')
    .addUserOption(opt => opt.setName('membre').setDescription('Chkoun (khliha khawya bash twri dyalek)')),
  async execute(interaction) {
    const target = interaction.options.getUser('membre') || interaction.user;
    const data = getUser(interaction.guildId, target.id);
    const needed = xpForLevel(data.level);

    const embed = infoEmbed(`📊 Rank dyal ${target.username}`, `**Level:** ${data.level}\n**XP:** ${data.xp} / ${needed}`)
      .setThumbnail(target.displayAvatarURL());

    await interaction.reply({ embeds: [embed] });
  },
};
